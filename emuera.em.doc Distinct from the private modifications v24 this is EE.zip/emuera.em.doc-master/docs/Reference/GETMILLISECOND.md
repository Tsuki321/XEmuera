---
hide:
  - toc
---

# GETMILLISECOND

| 関数名                                                                       | 引数 | 戻り値 |
| :--------------------------------------------------------------------------- | :--- | :----- |
| ![](../assets/images/IconEmuera.webp)[`GETMILLISECOND`](./GETMILLISECOND.md) | なし | `int`  |

!!! info "API"

    ```  { #language-erbapi }
	int GETMILLISECOND
    ```
	西暦0001年1月1日からの経過時間をミリ秒単位で取得します。  
	そのまま加減算ができるので経過時間などを調べるにはGETTIMEよりも適しています。  
	なお、返り値の精度は実行する環境にもよりますが、十数～数十ミリ秒程度です。  
	（数ミリ秒しか経過していない場合、同じ値が帰ってくることがあります）  
	パフォーマンスの測定を目的とする場合は注意してください。  

!!! hint "ヒント"

    命令、式中関数両方対応しています。

### 関連項目
- [GETSECOND](GETSECOND.md)
- [GETTIME](GETTIME.md)
